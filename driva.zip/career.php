<?php include('header-inner.php') ?>
<div class="main-wrapper inner--page">
	<section class="hero-banner inner-banner center-bg" style="background-image: url('images/aboutus-banner.png')">
	  <div class="container">
	    <div class="row">
	      <div class="col-lg-12 col-md-12 col-sm-12">
	      	<div class="partner-banner-content">
	      		<h1>Careers</h1>
	      		<text>Join and Grow with us and make an impect on<br>the world with your inspiring work</text>
	      	</div>
	      </div>
	    </div>
	  </div>
	</section>

	<section class="aboutus-sec">
		<div class="container">
			<div class="row">
				<div class="col-lg-8 offset-lg-2 text-center">
					<div class="about-content">
						<h2>Work with Driva</h2>
						<text> Unfortunately, at this time, we don't have any job vacancies. However, Send your CV to hr@drivaja.com so that we can add you to our talent pool, and I will notify you in case that we have a job opening for which you would be a good match. </text>
					</div>
				</div>
			</div>
		</div>
	</section>
	
</div>

<?php include('footer.php') ?>