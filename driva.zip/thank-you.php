<?php include('header-inner.php') ?>
	<div class="main-wrapper inner--page" style="background-color: #eff0f2;">
		<section class="thankyou-sec">
		   <div class="container">
		      <div class="row">
		         <div class="col-lg-8 offset-lg-2">
		            <div class="main-box">
		               <div class="row">
		                  <div class="col-lg-12 text-center">
		                     <h4>You are set!</h4>
		                     <div class="section-header-center">
		                        <h2>Thank you for your Order</h2>
		                     </div>
		                  </div>
		                  <div class="col-lg-12 text-center">
		                     <div class="payment-sec cct">
		                        <h4>Check your order status in the link below</h4>
		                        <div class="form-group">
		                           <a href="careers.html" class="primary-btn">Track</a>
		                        </div>
		                     </div>
		                  </div>
		               </div>		               
		            </div>
		         </div>
		      </div>
		   </div>
		</section>
	</div>
<?php include('footer.php') ?>